# Moxinggang overlay

This directory preserves the target-side prompt context separately from the public upstream repository.

## Contents

- `inline-system-instructions.txt`: the exact `response.instructions` value captured from `POST https://moxinggang.com/v1/responses`.
- `security-research/`: the Markdown documents fetched from `https://moxinggang.com/skills/security-research/current/`.
- `context-manifest.json`: capture-time paths, source URLs, character counts, hashes, and unresolved references.
- `sync-latest.ps1`: refreshes the remote Markdown layer without changing the upstream snapshot or the inline capture.

The source repository and commit used for the base package are documented in the parent `README_RECONSTRUCTED.md`.

