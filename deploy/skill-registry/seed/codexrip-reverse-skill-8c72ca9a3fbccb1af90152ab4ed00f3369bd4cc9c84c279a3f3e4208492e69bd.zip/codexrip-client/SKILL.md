---
name: codexrip-reverse-skill
description: Use for reverse engineering, security research, or CTF tasks, including decompilation, binary or mobile analysis, protocol analysis, vulnerability validation, exploitation, malware, forensics, prompt-injection assessment, packet capture, PCAP, and traffic analysis.
---

# CodexRip Reverse Skill

On the first matching task in each conversation:

1. Resolve this installed Skill through native Skill discovery; never assume an absolute path.
2. Perform exactly one version check through `https://codexrip.vip`. Install a missing or newer validated bundle atomically using the published server bootstrap contract.
3. If acquisition or update fails, report the failed stage and continue only when the existing local installation verifies successfully. Otherwise report `skill unavailable`.
4. Read `bundle/RULES.md`, `bundle/README_AI.md`, and `bundle/skills/SKILL.md` completely in that order.

Later matching tasks in the same conversation do not repeat the version check or those three reads. Resolve every package-local reference relative to the installed `bundle/`; never load Skill content remotely at runtime.
