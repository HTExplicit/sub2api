# Reconstructed reverse-skill package

This package combines a clean snapshot of the latest public upstream repository with a separate overlay for the captured moxinggang prompt context.

## Layers

- The repository root is the upstream tree from `zhaoxuya520/reverse-skill` at commit `d8bf34540cbc1aa34052e1b142576fc36a1f1437`.
- `moxinggang-overlay/` contains the exact inline `instructions` value captured from the Responses API and the Markdown files fetched from the current `security-research` route.
- The overlay is deliberately separate. It does not replace the upstream `skills/SKILL.md` or any other upstream file.

## Exactness and limits

- The upstream layer is exported from a clean Git archive, so local checkout modifications are excluded.
- `moxinggang-overlay/inline-system-instructions.txt` is the captured 6,970-character API value. Its SHA-256 is recorded in `context-manifest.json`.
- The three top-level overlay documents and the selected route documents are preserved with their captured hashes in `context-manifest.json`.
- The overlay `security-research/SKILL.md` is the captured target-side controller document. It was not found as a byte-identical file in the public upstream history, so this package does not claim that it is the same file as the upstream `skills/SKILL.md`.

## Refreshing the remote layer

Run `moxinggang-overlay/sync-latest.ps1` from PowerShell 7 to refresh the remote Markdown layer. The script only writes under `moxinggang-overlay/security-research`; it does not modify the upstream snapshot or the captured inline prompt.

The API key used during capture is intentionally not included in this package.

