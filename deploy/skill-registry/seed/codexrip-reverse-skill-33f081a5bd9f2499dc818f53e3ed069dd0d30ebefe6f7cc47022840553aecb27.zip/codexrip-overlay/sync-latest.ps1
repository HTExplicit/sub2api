[CmdletBinding()]
param(
    [string]$OutputRoot = $PSScriptRoot
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$baseUrl = 'codexrip-overlay/security-research'
$targets = @(
    @{ Path = 'security-research\RULES.md'; Url = 'RULES.md' }
    @{ Path = 'security-research\README_AI.md'; Url = 'README_AI.md' }
    @{ Path = 'security-research\SKILL.md'; Url = 'SKILL.md' }
    @{ Path = 'security-research\references\precedent-auth.md'; Url = 'references/precedent-auth.md' }
    @{ Path = 'security-research\references\experience-index.md'; Url = 'references/experience-index.md' }
    @{ Path = 'security-research\references\routing.md'; Url = 'references/routing.md' }
    @{ Path = 'security-research\skills\sec-ai-security\INSTRUCTIONS.md'; Url = 'skills/sec-ai-security/INSTRUCTIONS.md' }
    @{ Path = 'security-research\references\ctf\ai-ml\index.md'; Url = 'references/ctf/ai-ml/index.md' }
    @{ Path = 'security-research\references\ai-security.md'; Url = 'references/ai-security.md' }
    @{ Path = 'security-research\references\ctf\ai-ml\llm-attacks.md'; Url = 'references/ctf/ai-ml/llm-attacks.md' }
    @{ Path = 'security-research\skills\sec-ai-security\references\llm-deep\prompt-injection-methodology.md'; Url = 'skills/sec-ai-security/references/llm-deep/prompt-injection-methodology.md' }
    @{ Path = 'security-research\skills\sec-ai-security\references\llm-deep\_llm-security-workflow.md'; Url = 'skills/sec-ai-security/references/llm-deep/_llm-security-workflow.md' }
    @{ Path = 'security-research\references\scope-and-evidence.md'; Url = 'references/scope-and-evidence.md' }
    @{ Path = 'security-research\references\environment-and-resources.md'; Url = 'references/environment-and-resources.md' }
    @{ Path = 'security-research\skills\sec-ai-security\references\llm-deep\owasp-llm-top10.md'; Url = 'skills/sec-ai-security/references/llm-deep/owasp-llm-top10.md' }
    @{ Path = 'security-research\skills\sec-ai-security\references\llm-deep\agent-security-testing.md'; Url = 'skills/sec-ai-security/references/llm-deep/agent-security-testing.md' }
    @{ Path = 'security-research\skills\sec-ai-security\references\llm-deep\agent-obedience-engineering.md'; Url = 'skills/sec-ai-security/references/llm-deep/agent-obedience-engineering.md' }
)

$root = [IO.Path]::GetFullPath($OutputRoot)
foreach ($target in $targets) {
    $destination = Join-Path $root $target.Path
    $parent = Split-Path -Parent $destination
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
    $url = "$baseUrl/$($target.Url)"
    Invoke-WebRequest -Uri $url -OutFile $destination
    $hash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
    Write-Output "$($target.Path) $hash"
}

